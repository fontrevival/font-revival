Download every numbered ZIP part and extract them into the same folder. Together they form the complete web bundle.

# GPO Cuts 1904 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/gpo-cuts-1904/svg/multitone/gpo-1904-38.svg"
     alt="Three-masted steamship under sail" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Three-masted steamship under sail">
  <use href="collection/gpo-cuts-1904/web/icons-multitone.svg#gpo-1904-38"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/gpo-cuts-1904/web/icons.css">
<span class="fr-icon fr-gpo-1904-38" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Three-masted steamship under sail</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/gpo-cuts-1904/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/gpo-cuts-1904/LICENSE`,
`collection/gpo-cuts-1904/OFL.txt` and `collection/gpo-cuts-1904/FONT-LICENSES.txt`.
