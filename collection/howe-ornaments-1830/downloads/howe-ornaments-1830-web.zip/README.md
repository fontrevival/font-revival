# Howe Ornaments 1830 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/howe-ornaments-1830/svg/howe-1830-p013-pica-1.svg"
     alt="Twelve-ray sun and graduated four-petal wheels" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Twelve-ray sun and graduated four-petal wheels">
  <use href="collection/howe-ornaments-1830/web/icons.svg#howe-1830-p013-pica-1"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/howe-ornaments-1830/web/icons.css">
<span class="fr-icon fr-howe-1830-p013-pica-1" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Twelve-ray sun and graduated four-petal wheels</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/howe-ornaments-1830/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/howe-ornaments-1830/LICENSE`,
`collection/howe-ornaments-1830/OFL.txt` and `collection/howe-ornaments-1830/FONT-LICENSES.txt`.

The densest design uses default OpenType shaping to retain its complete outlines. Applications without shaping display a simplified compatibility drawing; use the SVG there for complete detail. Private tone layers remain available in the canonical master and SVG artwork.
