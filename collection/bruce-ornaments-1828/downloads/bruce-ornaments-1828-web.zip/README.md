# Bruce Ornaments 1828 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/bruce-ornaments-1828/svg/bruce-1828-p169-nonpareil-3.svg"
     alt="Solid bead between pointed teardrops" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Solid bead between pointed teardrops">
  <use href="collection/bruce-ornaments-1828/web/icons.svg#bruce-1828-p169-nonpareil-3"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/bruce-ornaments-1828/web/icons.css">
<span class="fr-icon fr-bruce-1828-p169-nonpareil-3" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Solid bead between pointed teardrops</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/bruce-ornaments-1828/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/bruce-ornaments-1828/LICENSE`,
`collection/bruce-ornaments-1828/OFL.txt` and `collection/bruce-ornaments-1828/FONT-LICENSES.txt`.
