Download every numbered ZIP part and extract them into the same folder. Together they form the complete web bundle.

# Baltimore Ornaments 1832 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/baltimore-ornaments-1832/svg/multitone/baltimore-1832-p131-90.svg"
     alt="Draped card border with cherub" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Draped card border with cherub">
  <use href="collection/baltimore-ornaments-1832/web/icons-multitone.svg#baltimore-1832-p131-90"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/baltimore-ornaments-1832/web/icons.css">
<span class="fr-icon fr-baltimore-1832-p131-90" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Draped card border with cherub</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/baltimore-ornaments-1832/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/baltimore-ornaments-1832/LICENSE`,
`collection/baltimore-ornaments-1832/OFL.txt` and `collection/baltimore-ornaments-1832/FONT-LICENSES.txt`.

All downloadable fonts use reviewed simplifications for the most detailed engravings. The editable master, SVGs and tonal PNGs retain the full historical outlines; use SVG for enlarged artwork.
