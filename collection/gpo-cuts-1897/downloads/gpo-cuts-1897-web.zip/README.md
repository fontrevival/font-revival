Download every numbered ZIP part and extract them into the same folder. Together they form the complete web bundle.

# GPO Cuts 1897 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/gpo-cuts-1897/svg/multitone/gpo-1897-seal-3.svg"
     alt="Revenue Cutter Service, Semper Paratus crest and crossed anchors" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Revenue Cutter Service, Semper Paratus crest and crossed anchors">
  <use href="collection/gpo-cuts-1897/web/icons-multitone.svg#gpo-1897-seal-3"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/gpo-cuts-1897/web/icons.css">
<span class="fr-icon fr-gpo-1897-seal-3" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Revenue Cutter Service, Semper Paratus crest and crossed anchors</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/gpo-cuts-1897/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/gpo-cuts-1897/LICENSE`,
`collection/gpo-cuts-1897/OFL.txt` and `collection/gpo-cuts-1897/FONT-LICENSES.txt`.
