# Baltimore Initials 1832 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/baltimore-initials-1832/svg/multitone/baltimore-1832-p59-six-line-pica-ornamented-m.svg"
     alt="Six Line Pica Ornamented letter M" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Six Line Pica Ornamented letter M">
  <use href="collection/baltimore-initials-1832/web/icons-multitone.svg#baltimore-1832-p59-six-line-pica-ornamented-m"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/baltimore-initials-1832/web/icons.css">
<span class="fr-icon fr-baltimore-1832-p59-six-line-pica-ornamented-m" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Six Line Pica Ornamented letter M</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/baltimore-initials-1832/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/baltimore-initials-1832/LICENSE`,
`collection/baltimore-initials-1832/OFL.txt` and `collection/baltimore-initials-1832/FONT-LICENSES.txt`.

The densest design uses default OpenType shaping to retain its complete outlines. Applications without shaping display a simplified compatibility drawing; use the SVG there for complete detail. Private tone layers remain available in the canonical master and SVG artwork.
