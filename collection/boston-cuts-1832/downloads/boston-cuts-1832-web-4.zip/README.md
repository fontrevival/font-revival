Download every numbered ZIP part and extract them into the same folder. Together they form the complete web bundle.

# Boston Cuts 1832 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/boston-cuts-1832/svg/multitone/boston-1832-p201-4.svg"
     alt="Globe on a three-legged stand" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.842773em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Globe on a three-legged stand">
  <use href="collection/boston-cuts-1832/web/icons-multitone.svg#boston-1832-p201-4"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/boston-cuts-1832/web/icons.css">
<span class="fr-icon fr-boston-1832-p201-4" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Globe on a three-legged stand</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/boston-cuts-1832/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. MIT licensed.

All downloadable fonts use reviewed simplifications for the most detailed engravings. The editable master, SVGs and tonal PNGs retain the full historical outlines; use SVG for enlarged artwork.
