Download every numbered ZIP part and extract them into the same folder. Together they form the complete web bundle.

# Figgins Cuts 1834 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/figgins-cuts-1834/svg/figgins-1834-p253-cut-1.svg"
     alt="Royal arms with lion, unicorn, shamrock and broad motto ribbon" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.941406em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Royal arms with lion, unicorn, shamrock and broad motto ribbon">
  <use href="collection/figgins-cuts-1834/web/icons.svg#figgins-1834-p253-cut-1"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/figgins-cuts-1834/web/icons.css">
<span class="fr-icon fr-figgins-1834-p253-cut-1" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Royal arms with lion, unicorn, shamrock and broad motto ribbon</span>
```

The font uses the solid artwork. SVG provides the three-tone version.
Keep `collection/figgins-cuts-1834/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. Artwork and CSS use MIT. Fonts are available under your choice
of MIT or SIL OFL 1.1 (`MIT OR OFL-1.1`), with no Reserved Font Names.
The license texts and scope are in `collection/figgins-cuts-1834/LICENSE`,
`collection/figgins-cuts-1834/OFL.txt` and `collection/figgins-cuts-1834/FONT-LICENSES.txt`.

The most detailed engravings require normal OpenType shaping, which assembles their complete outlines automatically. Software with shaping disabled displays a simplified compatibility outline. Use the SVG for full detail in those applications.
